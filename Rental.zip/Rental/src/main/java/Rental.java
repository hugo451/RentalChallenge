import model.Client;
import model.Rent;
import model.Tape;
import model.price.PrecoInfantil;
import model.price.PrecoLancamento;
import model.price.PrecoNormal;
import service.ExtratoGenerator;
import service.ExtratoHTML;
import service.ExtratoTexto;

public class Rental {
    public static void main(String[] args) {
        Client c1 = new Client("Juliana");

        c1.adicionaRent(new Rent(new Tape("O Exorcista", new PrecoNormal()), 3));
        c1.adicionaRent(new Rent(new Tape("Men in Black", new PrecoNormal()), 2));
        c1.adicionaRent(new Rent(new Tape("Jurassic Park III", new PrecoLancamento()), 3));
        c1.adicionaRent(new Rent(new Tape("Planeta dos Macacos", new PrecoLancamento()), 4));
        c1.adicionaRent(new Rent(new Tape("Pateta no Planeta dos Macacos", new PrecoInfantil()), 10));
        c1.adicionaRent(new Rent(new Tape("O Rei Leao", new PrecoInfantil()), 30));

        // Gerando extrato em Texto
        ExtratoGenerator extrato1 = new ExtratoTexto();
        System.out.println(c1.geraExtrato(extrato1));

        // Gerando extrato em HTML
        ExtratoGenerator extrato2 = new ExtratoHTML();
        System.out.println(c1.geraExtrato(extrato2));
    }
}