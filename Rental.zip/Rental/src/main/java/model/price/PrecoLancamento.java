package model.price;

public class PrecoLancamento implements PrecoStrategy {
    @Override
    public double calcularPreco(int diasAlugada) {
        return diasAlugada * 3;
    }

    @Override
    public int calcularPontosDeAlugadorFrequente(int diasAlugada) {
        return diasAlugada > 1 ? 2 : 1;
    }
}
