package model.price;

public interface PrecoStrategy {
    double calcularPreco(int diasAlugada);
    int calcularPontosDeAlugadorFrequente(int diasAlugada);
}
