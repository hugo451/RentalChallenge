package model.price;

public class PrecoInfantil implements PrecoStrategy {
    @Override
    public double calcularPreco(int diasAlugada) {
        double preco = 1.5;
        if (diasAlugada > 3) {
            preco += (diasAlugada - 3) * 1.5;
        }
        return preco;
    }

    @Override
    public int calcularPontosDeAlugadorFrequente(int diasAlugada) {
        return 1;
    }
}
