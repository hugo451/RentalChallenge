package model.price;

public class PrecoNormal implements PrecoStrategy {
    @Override
    public double calcularPreco(int diasAlugada) {
        double preco = 2;
        if (diasAlugada > 2) {
            preco += (diasAlugada - 2) * 1.5;
        }
        return preco;
    }

    @Override
    public int calcularPontosDeAlugadorFrequente(int diasAlugada) {
        return 1;
    }
}
