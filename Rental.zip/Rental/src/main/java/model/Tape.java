package model;

import model.price.PrecoStrategy;

public class Tape {
    private String titulo;
    private PrecoStrategy precoStrategy;

    public Tape(String titulo, PrecoStrategy precoStrategy) {
        this.titulo = titulo;
        this.precoStrategy = precoStrategy;
    }

    public String getTitulo() {
        return titulo;
    }

    public PrecoStrategy getPrecoStrategy() {
        return precoStrategy;
    }

    public void setPrecoStrategy(PrecoStrategy precoStrategy) {
        this.precoStrategy = precoStrategy;
    }
}
