package model;

public class Rent {
    private Tape tape;
    private int diasAlugada;

    public Rent(Tape tape, int diasAlugada) {
        this.tape = tape;
        this.diasAlugada = diasAlugada;
    }

    public Tape getTape() {
        return tape;
    }

    public int getDiasAlugada() {
        return diasAlugada;
    }

    public double calcularPreco() {
        return tape.getPrecoStrategy().calcularPreco(diasAlugada);
    }

    public int calcularPontosDeAlugadorFrequente() {
        return tape.getPrecoStrategy().calcularPontosDeAlugadorFrequente(diasAlugada);
    }
}

