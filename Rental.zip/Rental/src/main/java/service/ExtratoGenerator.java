package service;

import model.Client;

public interface ExtratoGenerator {
    String gerarExtrato(Client cliente);
}