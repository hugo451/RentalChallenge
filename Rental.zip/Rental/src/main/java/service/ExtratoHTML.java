package service;

import model.Client;
import model.Rent;

public class ExtratoHTML implements ExtratoGenerator {
    @Override
    public String gerarExtrato(Client cliente) {
        double valorTotal = 0.0;
        int pontosDeAlugadorFrequente = 0;
        StringBuilder resultado = new StringBuilder("<html><body>");
        resultado.append("<h1>Registro de Alugueis de ").append(cliente.getNome()).append("</h1>");
        resultado.append("<ul>");

        for (Rent aluguel : cliente.getAlugueis()) {
            double valorCorrente = aluguel.calcularPreco();
            pontosDeAlugadorFrequente += aluguel.calcularPontosDeAlugadorFrequente();

            // Adiciona as informações de cada aluguel
            resultado.append("<li>")
                    .append(aluguel.getTape().getTitulo())
                    .append(": ")
                    .append(valorCorrente)
                    .append("</li>");

            valorTotal += valorCorrente;
        }

        resultado.append("</ul>");
        resultado.append("<p><strong>Valor total devido:</strong> ").append(valorTotal).append("</p>");
        resultado.append("<p><strong>Você acumulou:</strong> ").append(pontosDeAlugadorFrequente)
                .append(" pontos de alugador frequente</p>");
        resultado.append("</body></html>");

        return resultado.toString();
    }
}
