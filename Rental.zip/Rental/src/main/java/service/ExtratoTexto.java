package service;

import model.Client;
import model.Rent;

public class ExtratoTexto implements ExtratoGenerator {
    @Override
    public String gerarExtrato(Client cliente) {
        final String fimDeLinha = System.getProperty("line.separator");
        double valorTotal = 0.0;
        int pontosDeAlugadorFrequente = 0;
        StringBuilder resultado = new StringBuilder("Registro de Alugueis de " + cliente.getNome() + fimDeLinha);

        for (Rent aluguel : cliente.getAlugueis()) {
            double valorCorrente = aluguel.calcularPreco();
            pontosDeAlugadorFrequente += aluguel.calcularPontosDeAlugadorFrequente();

            resultado.append("\t").append(aluguel.getTape().getTitulo()).append("\t").append(valorCorrente).append(fimDeLinha);
            valorTotal += valorCorrente;
        }

        resultado.append("Valor total devido: ").append(valorTotal).append(fimDeLinha);
        resultado.append("Voce acumulou ").append(pontosDeAlugadorFrequente).append(" pontos de alugador frequente");
        return resultado.toString();
    }
}
